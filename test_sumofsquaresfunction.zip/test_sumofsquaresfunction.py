from sumofsquares import sum_of_squaress

def test_sumofsquaresfunction():
	assert sum_of_squaress([8, 9, 3, 5]) == 179